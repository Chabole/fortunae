# fortunae
 Fortunae quer ser tornar uma biblioteca de análise financeira. Voltada pra importação de indicadores fundamentalistas atuais de ações ou fundos imobiliarios usando multithreading.
